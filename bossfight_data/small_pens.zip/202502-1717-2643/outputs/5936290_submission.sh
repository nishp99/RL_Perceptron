#!/bin/bash

# Parameters
#SBATCH --array=0-29%30
#SBATCH --cpus-per-task=8
#SBATCH --error=/nfs/nhome/live/npatel/yet_another_fucking_bossfight/procgen/bossfight/reinforce/results/gpu/penalties/202502-1717-2643/outputs/%A_%a_0_log.err
#SBATCH --gpus-per-node=1
#SBATCH --job-name=submitit
#SBATCH --mem=5GB
#SBATCH --nodes=1
#SBATCH --open-mode=append
#SBATCH --output=/nfs/nhome/live/npatel/yet_another_fucking_bossfight/procgen/bossfight/reinforce/results/gpu/penalties/202502-1717-2643/outputs/%A_%a_0_log.out
#SBATCH --partition=gpu
#SBATCH --signal=USR2@90
#SBATCH --time=3000
#SBATCH --wckey=submitit

# command
export SUBMITIT_EXECUTOR=slurm
srun --unbuffered --output /nfs/nhome/live/npatel/yet_another_fucking_bossfight/procgen/bossfight/reinforce/results/gpu/penalties/202502-1717-2643/outputs/%A_%a_%t_log.out --error /nfs/nhome/live/npatel/yet_another_fucking_bossfight/procgen/bossfight/reinforce/results/gpu/penalties/202502-1717-2643/outputs/%A_%a_%t_log.err /nfs/nhome/live/npatel/miniforge3/envs/bossfight_final_clean/bin/python -u -m submitit.core._submit /nfs/nhome/live/npatel/yet_another_fucking_bossfight/procgen/bossfight/reinforce/results/gpu/penalties/202502-1717-2643/outputs
